import React, { useEffect, useState } from 'react';
import { StreamChat } from 'stream-chat';
import {
  Attachment,
  Chat,
  Channel,
  ChannelHeader,
  ChannelList,
  LoadingIndicator,
  MessageInput,
  MessageList,
  Thread,
  Window,
} from 'stream-chat-react';

import { useClient } from './hooks/useClient';

import 'stream-chat-react/dist/css/v2/index.css';
import './layout.css';

const filters = { type: 'messaging' };
const options = { state: true, presence: true, limit: 10 };
const sort = { last_message_at: -1 };
const userToken = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VyX2lkIjoiYmlzd2FkZWVwIn0.99jiV_ffAvLstcAWx3yU0B3EOMmWHyt4cNg_Sa5UhWY';
const user = {
          id: 'biswadeep',
          name: 'Biswadeep Purkayastha',
          image: 'https://getstream.io/random_svg/?name=Biswadeep'
        };

const App = () => {
  
  const client = useClient({ apiKey: 'xweyehq2qrnt', userData: user, tokenOrProvider: userToken });

  useEffect(() => {
    if (!client) return;
  
  const;
 channel1 = client.channel('messaging', {
    image: 'https://getstream.io/random_svg/?name=Messages',
    name: 'Basic Messages',
  })
  const channel2 = client.channel('messaging', 'python', {
    name: 'All about Python',
    image: 'https://getstream.io/random_svg/?name=Python',
});
const channel3 = client.channel('messaging', 'datascience', {
    name: 'Data Science Lovers',
    image: 'https://getstream.io/random_svg/?name=Data',
});
const channel4 = client.channel('messaging', 'travel', {
    name: 'Travelling',
    image: 'https://getstream.io/random_svg/?name=Travel',
});
const channel5 = client.channel('messaging', 'jokes', {
    name: 'Jokes : Wanna laugh?',
    image: 'https://getstream.io/random_svg/?name=Jokes',
});

channel2.create();
channel3.create();
channel4.create();
channel5.create();

}, [client]);


  
  return (
    <Chat client={client} theme='messaging light'>
    <ChannelList filters={filters} sort={sort} options={options} />
    <Channel>
      <Window>
        <ChannelHeader />
        <MessageList />
        <MessageInput />
      </Window>
      <Thread />
    </Channel>
  </Chat>
  );
  };

export default App