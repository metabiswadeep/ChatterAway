import React from "react";
import { StreamChat } from "stream-chat";

const addUser = (name) => {
  
    server_client = StreamChat(api_key="xweyehq2qrnt", api_secret="u345g4r9squ5zunwatc3zq2q2yfqfhbjqytz6rd9hvr7cg5ftevu2hmkjcch8j9m");
    token = server_client.create_token(name);
    return token
}

export default addUser

