import React, { useEffect, useState } from 'react';
import { StreamChat } from 'stream-chat';
import {
  Attachment,
  Chat,
  Channel,
  ChannelHeader,
  ChannelList,
  LoadingIndicator,
  MessageInput,
  MessageList,
  Thread,
  Window,
} from 'stream-chat-react';

// we'll reuse `useClient` hook from the "Add a Channel List" example
import { useClient } from './hooks/useClient';

import 'stream-chat-react/dist/css/v2/index.css';
import './layout.css';

const userToken = 'eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJ1c2VyX2lkIjoiY29sZC12b2ljZS0xIiwiZXhwIjoxNjcxMjA3MjMxfQ.2oZEKw1spFBepN23JJVOCuQnfCgjh1J4j85AtcOFrbU';

const user = {
  id: 'cold-voice-1',
  name: 'cold',
  image: 'https://getstream.io/random_png/?id=cold-voice-1&name=cold',
};

const filters = { type: 'messaging', members: { $in: ['cold-voice-1'] } };
const sort = { last_message_at: -1 };

const attachments = [];

const CustomAttachment = (props) => {
  const { attachments } = props;
  const [attachment] = attachments || [];

  if (attachment?.type === 'product')
    return (
      <div>
        Product:
        <a href={attachment.url} rel='noreferrer'>
          <img alt='custom-attachment' height='100px' src={attachment.image} />
          <br />
          {attachment.name}
        </a>
      </div>
    );

  return <Attachment {...props} />;
};

const App = () => {
  const chatClient = useClient({ apiKey: 'dz5f4d5kzrue', userData: user, tokenOrProvider: userToken });

  useEffect(() => {
    if (!chatClient) return;

    const initAttachmentMessage = async () => {
      const [channelResponse] = await chatClient.queryChannels(filters, sort);

      await channelResponse.sendMessage({
        text: 'Your selected product is out of stock, would you like to select one of these alternatives?',
        attachments,
      });
    };

    // initAttachmentMessage();
  }, [chatClient]);

  if (!chatClient) {
    return <LoadingIndicator />;
  }

  return (
    <Chat client={chatClient} theme='messaging light'>
      <ChannelList filters={filters} sort={sort} />
      <Channel Attachment={CustomAttachment}>
        <Window>
          <ChannelHeader />
          <MessageList />
          <MessageInput />
        </Window>
        <Thread />
      </Channel>
    </Chat>
  );
};

export default App;